# The Trouble With Hoyt-Schermerhorn: data bundle

Data behind the piece at https://gizmowarehouse.org/gizmo/hoyt-schermerhorn-crime-analysis. Snapshot 2026-10-19.
Questions: joe@group17a.com.

## Source

NYPD Complaint Data, Historic (NYC Open Data qgea-i56i) and Year-To-Date (5uac-w243), as published. Every
file is derived from those two datasets. Coordinates are NYPD's: each complaint is placed at a midblock or
intersection point, never an address. Victim and suspect demographic columns are not included. The 2026
file covers January through June only; 2025 includes late-reported rows held from an earlier pull
(vintage = held), so 2025 counts can exceed what a fresh download shows.

## Definitions

- A **complaint** is a crime reported to or recorded by the police, one incident per record. Not a 311 request.
- **Violent** means ky_cd 101 (murder), 105 (robbery) and 106 (felony assault). The four classes split those:
  street robbery, robbery that began as shoplifting or in a store, assault on an officer, and other felony assault.
- **Since 2006** comparisons in the piece use single years (2006 against 2025) and only offense codes that
  existed in 2006; the yearly series here carries every code, and the piece's methods note states both figures.
- **The courthouse point** is every complaint within 15 m of 120 Schermerhorn Street (Brooklyn Criminal
  Court and Central Booking). Hours there are when complaints were recorded, not when anything happened.
- **Map cells** are the 2,854 cells of a 0.33-mile square grid over the city; cell 40_42 is the one the piece is about.

## Files

### hoyt-schermerhorn-crime-analysis-core-incidents.csv

Every complaint within 500 m of the Hoyt-Schermerhorn station, 2006 to June 2026: the violent classes plus petit and grand larceny, theft of services, drugs and weapons. The first line is a comment with the snapshot and source.

| column | meaning |
|---|---|
| `cmplnt_num` | NYPD complaint id (unique per incident) |
| `date` | date the incident began (cmplnt_fr_dt) |
| `time` | time it began (cmplnt_fr_tm; 00:00 and 12:00 are often placeholders, see default_time) |
| `year` | year of date |
| `hour` | hour of time, 0 to 23 |
| `dow` | weekday, 0 = Monday |
| `ky_cd` | NYPD offense class code (101 murder, 105 robbery, 106 felony assault, 341 petit larceny, 109 grand larceny, 344 misdemeanor assault, ...) |
| `ofns_desc` | offense description for ky_cd |
| `pd_cd` | NYPD internal classification code |
| `pd_desc` | description for pd_cd (e.g. ROBBERY, BEGAN AS SHOPLIFTING) |
| `law_cat_cd` | FELONY, MISDEMEANOR or VIOLATION |
| `crm_atpt_cptd_cd` | COMPLETED or ATTEMPTED |
| `prem_typ_desc` | premise type as recorded (STREET, CHAIN STORE, ...) |
| `loc_of_occur_desc` | INSIDE, FRONT OF, OPPOSITE OF, REAR OF (often blank) |
| `juris_desc` | responding jurisdiction (NYPD, transit, housing) |
| `lat` | latitude as published by NYPD, rounded to a midblock or intersection |
| `lon` | longitude, same |
| `dist_m` | meters from the Hoyt-Schermerhorn station point |
| `cell_id` | id of the 0.33-mile map cell the point falls in |
| `zone` | street_stores, courthouse (within 15 m of 120 Schermerhorn), or transit (station footprints) |
| `class` | street_robbery, retail_robbery (began as shoplifting or in a store), other_assault, officer_assault, homicide, or not_violent |
| `point_id` | id of the rounded point (all complaints at identical coordinates share one) |
| `default_time` | true when the time is a placeholder (midnight or noon) |
| `lag_days` | days between the incident date and the report date |
| `vintage` | main (the current Open Data files) or held (late-reported 2025 rows from an earlier pull) |
| `reported_by_h1_end` | true when the report date is on or before June 30 of the incident year (used for first-half comparisons) |

### hoyt-schermerhorn-crime-analysis-yearly-series.csv

Violent complaints per year by place, class and definition variant, so every figure in the piece can be recomputed under every rule.

| column | meaning |
|---|---|
| `geo` | core400 (within 400 m of the station), core300, core500, core400_ex_courthouse, cell_40_42, pct84, brooklyn, city |
| `rule` | primary (ky_cd 101/105/106) or wide (adds negligent homicide 102/103) |
| `transit` | in = complaints on station footprints included; out = excluded |
| `default_time` | true when the time is a placeholder (midnight or noon) |
| `vintage` | main (the current Open Data files) or held (late-reported 2025 rows from an earlier pull) |
| `window` | full year, same_year_report, h1_full (Jan to Jun), or h1_reported (Jan to Jun, reported by June 30) |
| `year` | year of date |
| `cls` | offense class (see class above; all = every class) |
| `n` | count of complaints |

### hoyt-schermerhorn-crime-analysis-cell-ranking.csv

All 2,854 map cells: average violent complaints per year in the 2010s, the 2024 to 2025 total, and the ratio.

| column | meaning |
|---|---|
| `cell_id` | id of the 0.33-mile map cell the point falls in |
| `cls` | offense class (see class above; all = every class) |
| `base` | average violent complaints per year, 2010 to 2019 |
| `recent` | violent complaints, 2024 and 2025 combined |
| `ratio` | recent per year divided by base |
| `name` | nearest intersection, for finding the cell |

### hoyt-schermerhorn-crime-analysis-dq-audit.csv

The data-quality audit the piece was gated on: 58 tests with their status, threshold, reading and the caveat each one adds.

| column | meaning |
|---|---|
| `id` | test id |
| `group` | test family |
| `title` | what the test checks |
| `status` | pass, warn, report, kill, fail or skipped |
| `threshold` | the pass threshold, as JSON |
| `reading` | plain-language result |
| `affects` | which of the piece's claims the test guards |
| `footnote` | the caveat the page prints when the test warns |
| `value` | the measured value, as JSON |

## Terms

The underlying data is public under the NYC Open Data terms of use. These derived files may be reused with
attribution to NYPD / NYC Open Data and a link to the piece. No warranty: NYPD revises its files, and a later
download will not match this snapshot exactly.
